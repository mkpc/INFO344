﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure.Storage.Table.DataServices;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
using System.Xml;
using System.Xml.Linq;

namespace WebRole1
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        //private static List<string> visited = new List<string>();
        private static CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                ConfigurationManager.AppSettings["StorageConnectionString"]);

        [WebMethod]
        public void reset()
        {

            //Queue for loading sitemap from robots.txt
            CloudQueueClient queueClientForSiteMap = storageAccount.CreateCloudQueueClient();
            CloudQueue queueForSiteMap = queueClientForSiteMap.GetQueueReference("sitemapurl");

            //Queue for loading sitemap 
            CloudQueueClient queueClientForHtml = storageAccount.CreateCloudQueueClient();
            CloudQueue queueForHtml = queueClientForHtml.GetQueueReference("htmlurl");

            CloudQueueClient queueClientForCommand = storageAccount.CreateCloudQueueClient();
            CloudQueue queueForCommand = queueClientForCommand.GetQueueReference("command");

            CloudTableClient tableClientForUrlData = storageAccount.CreateCloudTableClient();
            CloudTable tableForData = tableClientForUrlData.GetTableReference("urldata");

            CloudQueueClient queueClientForRobots = storageAccount.CreateCloudQueueClient();
            CloudQueue queueForRobots = queueClientForCommand.GetQueueReference("robots");

            CloudTableClient tableClientForError = storageAccount.CreateCloudTableClient();
            CloudTable tableForError = tableClientForError.GetTableReference("errormsg");

            queueForRobots.Clear();
            queueForCommand.Clear();
            queueForHtml.Clear();
            queueForSiteMap.Clear();
            tableForData.DeleteIfExists();
            tableForError.DeleteIfExists();

        }

        [WebMethod]
        public void start()
        {
            reset();

            CloudQueueClient queueClientForCommand = storageAccount.CreateCloudQueueClient();
            CloudQueue queueForCommand = queueClientForCommand.GetQueueReference("command");
            queueForCommand.CreateIfNotExists();

            CloudQueueClient queueClientForRobots = storageAccount.CreateCloudQueueClient();
            CloudQueue queueForRobots = queueClientForCommand.GetQueueReference("robots");
            queueForRobots.CreateIfNotExists();



            //send robots.txt address to worker role
            CloudQueueMessage robotsMessage = new CloudQueueMessage("http://www.cnn.com/robots.txt");
            queueForRobots.AddMessage(robotsMessage);

            CloudQueueMessage robotsMessage2 = new CloudQueueMessage("http://bleacherreport.com/robots.txt");
            queueForRobots.AddMessage(robotsMessage2);

            //send start command to worker role
            CloudQueueMessage commandMessage = new CloudQueueMessage("start");
            queueForCommand.AddMessage(commandMessage);
        }


        [WebMethod]
        public void stop()
        {

            CloudQueueClient queueClientForCommand = storageAccount.CreateCloudQueueClient();
            CloudQueue queueForCommand = queueClientForCommand.GetQueueReference("command");
            queueForCommand.CreateIfNotExists();

            CloudQueueMessage stopMessage = new CloudQueueMessage("Stop");
            queueForCommand.AddMessage(stopMessage);
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string searchFromTable(string url)
        {
            try
            {
                var temp = url;
                if (temp.Contains("www.cnn.com"))
                {
                    if (temp.EndsWith("html/"))
                    {
                        temp = temp.Replace("html/", "html");
                    }
                    if (temp.EndsWith("/"))
                    {
                        temp = temp + "index.html";
                    }
                    if (temp.EndsWith(".com") || temp.EndsWith(".cnn"))
                    {
                        temp = temp + "/index.html";
                    }
                    if (temp.Contains(" "))
                    {
                        temp = temp.Replace(" ", "");
                    }

                }

                temp = Uri.EscapeDataString(temp);

                CloudTableClient tableClientForUrlData = storageAccount.CreateCloudTableClient();
                CloudTable tableForData = tableClientForUrlData.GetTableReference("urldata");

                List<String> result = new List<string>();

                TableQuery<urlData> queryResult = new TableQuery<urlData>()
                    .Where(TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, temp));

                foreach (urlData entity in tableForData.ExecuteQuery(queryResult))
                {
                    result.Add(Uri.UnescapeDataString(entity.RowKey) + " || " + entity.title);
                }
                if (result.Count == 0)
                {
                    temp = temp.Replace("%2Findex.html", "");
                    TableQuery<urlData> queryResultOther = new TableQuery<urlData>()
                   .Where(TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, temp));
                    foreach (urlData entity in tableForData.ExecuteQuery(queryResultOther))
                    {
                        
                        result.Add(Uri.UnescapeDataString(entity.RowKey) + " | " + entity.title);
                    }
                }
                return new JavaScriptSerializer().Serialize(result);
            }
            catch (StorageException ex)
            {
                return "Table is not ready yet, please try again";
            }


        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string updateStats()
        {
            CloudTableClient tableClientForStats = storageAccount.CreateCloudTableClient();
            CloudTable tableForstats = tableClientForStats.GetTableReference("stats");
            TableOperation retrieveOperation = TableOperation.Retrieve<stats>("worker", "workerrowkey");
            TableResult retrievedResult = tableForstats.Execute(retrieveOperation);
            int cpu = (((stats)retrievedResult.Result).cpu);
            int mem = (((stats)retrievedResult.Result).mem);
            int qsize = (((stats)retrievedResult.Result).htmlQSize);
            int crawledSize = (((stats)retrievedResult.Result).crawledSize);
            string status = (((stats)retrievedResult.Result).status);
            int deqcounter = (((stats)retrievedResult.Result).deqcounter);

            string result = "System status : " + status + " || #Discovered HTML : " + qsize + " entries || #Crawled URL : " + deqcounter + " || Index of table : " + crawledSize + " || CPU useage: " + cpu + "/100 || Memory available  : " + mem + "MB";



            return result;
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string getLastTen()
        {
            try
            {
                List<string> result = new List<string>();
                CloudTableClient tableClientForUrlData = storageAccount.CreateCloudTableClient();
                CloudTable tableForData = tableClientForUrlData.GetTableReference("urldata");

                string timeRowKey = string.Format("{0:D19}", DateTime.MaxValue.Ticks - DateTime.UtcNow.Ticks);
                TableQuery<urlData> queryResultOther = new TableQuery<urlData>()
                      .Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.GreaterThan, timeRowKey)).Take(10);


                foreach (urlData entity in tableForData.ExecuteQuery(queryResultOther))
                {
                    result.Add("URL : " + Uri.UnescapeDataString(entity.RowKey) + " || Title:  " + entity.title);
                }



                return new JavaScriptSerializer().Serialize(result);
            }
            catch (Exception ex)
            {
                return "null";
            }
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string getERROR()
        {
            try
            {
                List<string> result = new List<string>();
                CloudTableClient tableClientForError = storageAccount.CreateCloudTableClient();
                CloudTable tableForData = tableClientForError.GetTableReference("errormsg");

                string timeRowKey = string.Format("{0:D19}", DateTime.MaxValue.Ticks - DateTime.UtcNow.Ticks);
                TableQuery<errorMessage> queryResultOther = new TableQuery<errorMessage>()
                      .Where(TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.GreaterThan, timeRowKey)).Take(10);


                foreach (errorMessage entity in tableForData.ExecuteQuery(queryResultOther))
                {
                    result.Add("URL : " + Uri.UnescapeDataString(entity.RowKey) + " || ERROR MESSAGE:  " + entity.error);
                }
                if (result.Count == 0)
                {
                    return "null";
                }
                return new JavaScriptSerializer().Serialize(result);
            }
            catch (Exception ex)
            {
                return "null";
            }
        }
    }
}




