﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebRole1
{

    public class urlData : TableEntity
    {
        public urlData(string url)
        {
            this.PartitionKey = string.Format("{0:D19}", DateTime.MaxValue.Ticks - DateTime.UtcNow.Ticks);
            this.RowKey = url;
            // this.title = title;
        }

        public urlData() { }

        //public string url { get; set; }
        public string title { get; set; }
        public string date { get; set; }
    }
}